'use client';

import { useState } from 'react';
import Link from 'next/link';
import { PageShell } from '@/components/layout/page-shell';
import { StatusBadge } from '@/components/ui/status-badge';
import { ScoreBar } from '@/components/ui/score-bar';
import { useCompanies } from '@/lib/api/client';
import { formatNumber } from '@/lib/utils/format';
import { Search } from 'lucide-react';

export default function CompaniesPage() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { data, isLoading } = useCompanies({ search: search || undefined, status: status || undefined, page, per_page: 50 });
  const companies = data?.data ?? [];

  return (
    <PageShell title="Companies">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search name or domain..."
            className="w-full pl-9 pr-3 py-1.5 text-sm border border-input rounded-md bg-background"
          />
        </div>
        <select
          value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}
          className="px-3 py-1.5 text-sm border border-input rounded-md bg-background"
        >
          <option value="">All statuses</option>
          <option value="qualified">Qualified</option>
          <option value="disqualified">Disqualified</option>
          <option value="new">New</option>
          <option value="prequal_queued">Prequal queued</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">Company</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">Domain</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">Industry</th>
              <th className="text-right px-4 py-3 font-medium text-muted-foreground">Employees</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">Score</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {isLoading ? (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">Loading...</td></tr>
            ) : companies.length === 0 ? (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No companies found</td></tr>
            ) : (
              companies.map((c) => (
                <tr key={c.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3">
                    <Link href={`/companies/${c.id}`} className="font-medium text-primary hover:underline">{c.name}</Link>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{c.domain ?? '—'}</td>
                  <td className="px-4 py-3 text-xs">{c.industry ?? '—'}</td>
                  <td className="px-4 py-3 text-right text-xs tabular-nums">{formatNumber(c.employee_count)}</td>
                  <td className="px-4 py-3">{c.latest_status ? <StatusBadge status={c.latest_status} /> : '—'}</td>
                  <td className="px-4 py-3"><ScoreBar score={c.latest_score} /></td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-4">
        <button onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1}
          className="px-3 py-1.5 text-sm rounded-md border border-border hover:bg-muted disabled:opacity-50">Previous</button>
        <span className="text-xs text-muted-foreground">Page {page}</span>
        <button onClick={() => setPage(page + 1)} disabled={companies.length < 50}
          className="px-3 py-1.5 text-sm rounded-md border border-border hover:bg-muted disabled:opacity-50">Next</button>
      </div>
    </PageShell>
  );
}
