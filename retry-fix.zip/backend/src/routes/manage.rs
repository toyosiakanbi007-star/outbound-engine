// src/routes/manage.rs
//
// Management endpoints:
//   POST /api/clients/:id/flush-companies  — delete all companies + reset cursors
//   POST /api/queue-status/retry           — requeue failed jobs + reset candidates

use axum::{
    extract::{Path, State},
    http::StatusCode,
    Json,
};
use serde::Deserialize;
use serde_json::{json, Value as JsonValue};
use tracing::{error, info, warn};
use uuid::Uuid;

use crate::AppState;

// ============================================================================
// POST /api/clients/:id/flush-companies
// ============================================================================

#[derive(Debug, Deserialize)]
pub struct FlushCompaniesRequest {
    #[serde(default = "default_true")]
    pub reset_cursors: bool,
    #[serde(default = "default_true")]
    pub cancel_jobs: bool,
}

fn default_true() -> bool { true }

pub async fn flush_companies(
    State(state): State<AppState>,
    Path(client_id): Path<Uuid>,
    Json(body): Json<FlushCompaniesRequest>,
) -> Result<Json<JsonValue>, (StatusCode, Json<JsonValue>)> {
    let exists: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM clients WHERE id = $1)")
        .bind(client_id)
        .fetch_one(&state.db)
        .await
        .map_err(|e| { error!("DB error: {:?}", e); db_error("DB error") })?;

    if !exists {
        return Err(not_found("Client not found"));
    }

    // Delete all derived data
    let prequal_deleted = sqlx::query(
        "DELETE FROM company_prequal WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)"
    ).bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);

    let _ = sqlx::query("DELETE FROM v3_hypotheses WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)")
        .bind(client_id).execute(&state.db).await;
    let _ = sqlx::query("DELETE FROM v3_evidence WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)")
        .bind(client_id).execute(&state.db).await;
    let _ = sqlx::query("DELETE FROM company_news WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)")
        .bind(client_id).execute(&state.db).await;
    let _ = sqlx::query("DELETE FROM discovered_urls WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)")
        .bind(client_id).execute(&state.db).await;
    let _ = sqlx::query("DELETE FROM offer_fit_decisions WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)")
        .bind(client_id).execute(&state.db).await;
    let _ = sqlx::query("DELETE FROM company_snapshots WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)")
        .bind(client_id).execute(&state.db).await;

    let candidates_deleted = sqlx::query("DELETE FROM company_candidates WHERE client_id = $1")
        .bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);

    let companies_deleted = sqlx::query("DELETE FROM companies WHERE client_id = $1")
        .bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);

    let mut cursors_reset: u64 = 0;
    if body.reset_cursors {
        cursors_reset = sqlx::query("DELETE FROM company_fetch_runs WHERE client_id = $1")
            .bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);
    }

    let mut jobs_cancelled: u64 = 0;
    if body.cancel_jobs {
        jobs_cancelled = sqlx::query(
            r#"UPDATE jobs SET status = 'failed', last_error = 'cancelled (flush)', completed_at = NOW(), updated_at = NOW()
               WHERE client_id = $1 AND status IN ('pending', 'running')"#
        ).bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);
    }

    info!(
        "Flushed client {}: {} companies, {} candidates, {} prequal, {} cursors, {} jobs",
        client_id, companies_deleted, candidates_deleted, prequal_deleted, cursors_reset, jobs_cancelled
    );

    Ok(Json(json!({
        "data": {
            "companies_deleted": companies_deleted,
            "candidates_deleted": candidates_deleted,
            "prequal_deleted": prequal_deleted,
            "cursors_reset": cursors_reset,
            "jobs_cancelled": jobs_cancelled,
        }
    })))
}

// ============================================================================
// POST /api/queue-status/retry — requeue failed jobs + reset their candidates
// ============================================================================

#[derive(Debug, Deserialize)]
pub struct RetryJobsRequest {
    pub job_ids: Option<Vec<Uuid>>,
    pub job_type: Option<String>,
    pub client_id: Option<Uuid>,
    pub failed_after: Option<chrono::DateTime<chrono::Utc>>,
}

pub async fn retry_jobs(
    State(state): State<AppState>,
    Json(body): Json<RetryJobsRequest>,
) -> Result<Json<JsonValue>, (StatusCode, Json<JsonValue>)> {
    // Step 1: Find the failed jobs we're about to retry (need payloads for candidate reset)
    let jobs_to_retry: Vec<(Uuid, String, JsonValue)> = if let Some(ref ids) = body.job_ids {
        let mut rows = Vec::new();
        for id in ids {
            if let Ok(Some(row)) = sqlx::query_as::<_, (Uuid, String, JsonValue)>(
                "SELECT id, job_type, payload FROM jobs WHERE id = $1 AND status = 'failed'"
            ).bind(id).fetch_optional(&state.db).await {
                rows.push(row);
            }
        }
        rows
    } else {
        sqlx::query_as::<_, (Uuid, String, JsonValue)>(
            r#"SELECT id, job_type, payload FROM jobs
               WHERE status = 'failed'
                 AND ($1::text IS NULL OR job_type = $1)
                 AND ($2::uuid IS NULL OR client_id = $2)
                 AND ($3::timestamptz IS NULL OR completed_at >= $3)"#,
        )
        .bind(body.job_type.as_deref())
        .bind(body.client_id)
        .bind(body.failed_after)
        .fetch_all(&state.db)
        .await
        .unwrap_or_default()
    };

    if jobs_to_retry.is_empty() {
        return Ok(Json(json!({
            "data": { "jobs_retried": 0, "candidates_reset": 0 }
        })));
    }

    // Step 2: Reset candidates for prequal_batch jobs
    let mut candidates_reset: u64 = 0;
    for (job_id, job_type, payload) in &jobs_to_retry {
        if job_type == "prequal_batch" {
            // Extract candidate_ids from payload and reset them
            if let Some(candidate_ids) = payload.get("candidate_ids").and_then(|v| v.as_array()) {
                for cid in candidate_ids {
                    if let Some(cid_str) = cid.as_str() {
                        if let Ok(cid_uuid) = Uuid::parse_str(cid_str) {
                            let r = sqlx::query(
                                r#"UPDATE company_candidates
                                   SET status = 'prequal_queued',
                                       prequal_started_at = NULL,
                                       prequal_last_error = NULL,
                                       updated_at = NOW()
                                   WHERE id = $1
                                     AND status IN ('prequal_in_progress', 'prequal_error', 'qualified', 'disqualified')"#
                            )
                            .bind(cid_uuid)
                            .execute(&state.db)
                            .await;
                            if let Ok(r) = r { candidates_reset += r.rows_affected(); }
                        }
                    }
                }
            }
        } else if job_type == "prequal_dispatch" {
            // Reset all prequal_error candidates for this client
            if let Some(cid) = payload.get("client_id").and_then(|v| v.as_str()) {
                if let Ok(client_uuid) = Uuid::parse_str(cid) {
                    let r = sqlx::query(
                        r#"UPDATE company_candidates
                           SET status = 'new', prequal_started_at = NULL, prequal_last_error = NULL, updated_at = NOW()
                           WHERE client_id = $1 AND status = 'prequal_error'"#
                    )
                    .bind(client_uuid)
                    .execute(&state.db)
                    .await;
                    if let Ok(r) = r { candidates_reset += r.rows_affected(); }
                }
            }
        }
    }

    // Step 3: Requeue the jobs
    let job_ids: Vec<Uuid> = jobs_to_retry.iter().map(|(id, _, _)| *id).collect();
    let retried = sqlx::query(
        r#"UPDATE jobs SET status = 'pending', last_error = NULL,
           assigned_worker = NULL, completed_at = NULL, run_at = NOW(), updated_at = NOW()
           WHERE id = ANY($1) AND status = 'failed'"#,
    )
    .bind(&job_ids)
    .execute(&state.db)
    .await
    .map(|r| r.rows_affected())
    .map_err(|e| { error!("Retry error: {:?}", e); db_error("Retry failed") })?;

    info!("Retried {} jobs, reset {} candidates", retried, candidates_reset);

    Ok(Json(json!({
        "data": {
            "jobs_retried": retried,
            "candidates_reset": candidates_reset,
        }
    })))
}

// ============================================================================
fn db_error(msg: &str) -> (StatusCode, Json<JsonValue>) {
    (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({ "error": { "code": "db_error", "message": msg } })))
}
fn not_found(msg: &str) -> (StatusCode, Json<JsonValue>) {
    (StatusCode::NOT_FOUND, Json(json!({ "error": { "code": "not_found", "message": msg } })))
}
