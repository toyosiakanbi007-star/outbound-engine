'use client';

import { useState } from 'react';
import { PageShell } from '@/components/layout/page-shell';
import { StatusBadge } from '@/components/ui/status-badge';
import { ScoreBar } from '@/components/ui/score-bar';
import { JsonViewer, CollapsibleSection } from '@/components/ui/json-viewer';
import { useCompanyDetail, useCompanyFullPrequal, useRerunPrequal } from '@/lib/api/client';
import { RefreshCw } from 'lucide-react';

const TABS = ['overview', 'hypotheses', 'news', 'raw'] as const;
type Tab = typeof TABS[number];

export default function CompanyDetailPage({ params }: { params: { id: string } }) {
  const { id } = params;
  const { data, isLoading, isError, error } = useCompanyDetail(id);
  const [tab, setTab] = useState<Tab>('overview');
  const rerunPrequal = useRerunPrequal(id);

  const needsFullPrequal = tab === 'hypotheses' || tab === 'news' || tab === 'raw';
  const { data: fullPrequalData, isLoading: fullPrequalLoading } = useCompanyFullPrequal(id, needsFullPrequal);
  const fullResult = fullPrequalData?.data?.full_result;

  if (isLoading) return <PageShell title="Loading..."><p className="text-muted-foreground">Loading company details...</p></PageShell>;
  if (isError) return <PageShell title="Error"><p className="text-red-600">Failed to load company: {(error as any)?.message ?? 'Unknown error'}</p></PageShell>;
  if (!data?.data) return <PageShell title="Not found"><p className="text-muted-foreground">Company not found</p></PageShell>;

  const { company, latest_candidate, latest_prequal, run_history_count } = data.data;

  return (
    <PageShell
      title={company.name}
      description={company.domain ?? undefined}
      actions={
        <button onClick={() => rerunPrequal.mutate()} disabled={rerunPrequal.isPending}
          className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border hover:bg-muted disabled:opacity-50">
          <RefreshCw className={`w-3.5 h-3.5 ${rerunPrequal.isPending ? 'animate-spin' : ''}`} /> Rerun prequal
        </button>
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
        <div><span className="text-muted-foreground">Industry:</span> {company.industry ?? '—'}</div>
        <div><span className="text-muted-foreground">Employees:</span> {company.employee_count ?? '—'}</div>
        <div><span className="text-muted-foreground">Location:</span> {[company.city, company.region, company.country].filter(Boolean).join(', ') || '—'}</div>
        <div><span className="text-muted-foreground">Source:</span> {company.source ?? '—'}</div>
      </div>

      <div className="flex items-center gap-4 mb-6">
        {latest_candidate && <StatusBadge status={latest_candidate.status} />}
        {latest_prequal && <ScoreBar score={latest_prequal.score} />}
        <span className="text-xs text-muted-foreground">{run_history_count} run(s)</span>
      </div>

      <div className="flex gap-1 border-b border-border mb-4">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-3 py-2 text-sm font-medium border-b-2 transition-colors capitalize ${tab === t ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
            {t === 'raw' ? 'Raw JSON' : t}
          </button>
        ))}
      </div>

      {tab === 'overview' && <OverviewTab prequal={latest_prequal} />}
      {tab === 'hypotheses' && <HypothesesTab fullResult={fullResult} loading={fullPrequalLoading} />}
      {tab === 'news' && <NewsTab fullResult={fullResult} loading={fullPrequalLoading} />}
      {tab === 'raw' && <RawTab fullResult={fullResult} loading={fullPrequalLoading} />}
    </PageShell>
  );
}

function OverviewTab({ prequal }: { prequal: any }) {
  if (!prequal) return <p className="text-sm text-muted-foreground">No prequal results yet</p>;
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="bg-card border border-border rounded-lg p-4 space-y-3">
        <h3 className="text-sm font-medium">Prequal result</h3>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div><span className="text-muted-foreground">Score:</span> <span className="font-mono">{prequal.score?.toFixed(2)}</span></div>
          <div><span className="text-muted-foreground">Qualifies:</span> {prequal.qualifies ? <span className="text-emerald-600">Yes</span> : <span className="text-red-600">No</span>}</div>
          <div><span className="text-muted-foreground">Evidence:</span> {prequal.evidence_count ?? '—'}</div>
          <div><span className="text-muted-foreground">Sources:</span> {prequal.distinct_sources ?? '—'}</div>
        </div>
        {prequal.gates_passed?.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-1">Gates passed</p>
            <div className="flex flex-wrap gap-1">{prequal.gates_passed.map((g: string) => (
              <span key={g} className="px-1.5 py-0.5 text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 rounded">{g}</span>
            ))}</div>
          </div>
        )}
        {prequal.gates_failed?.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-1">Gates failed</p>
            <div className="flex flex-wrap gap-1">{prequal.gates_failed.map((g: string) => (
              <span key={g} className="px-1.5 py-0.5 text-xs bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 rounded">{g}</span>
            ))}</div>
          </div>
        )}
        {prequal.why_now_indicators?.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-1">Why now</p>
            <div className="flex flex-wrap gap-1">{prequal.why_now_indicators.map((w: string) => (
              <span key={w} className="px-1.5 py-0.5 text-xs bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 rounded">{w}</span>
            ))}</div>
          </div>
        )}
      </div>
      <div className="bg-card border border-border rounded-lg p-4 space-y-3">
        <h3 className="text-sm font-medium">Decision</h3>
        {prequal.prequal_reasons?.summary && <p className="text-sm">{prequal.prequal_reasons.summary}</p>}
        {prequal.prequal_reasons?.reasons?.length > 0 && (
          <ul className="space-y-1">{prequal.prequal_reasons.reasons.map((r: string, i: number) => (
            <li key={i} className="text-xs text-muted-foreground">• {r}</li>
          ))}</ul>
        )}
        {prequal.prequal_reasons?.gates_failed_explained?.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-1">Why disqualified</p>
            {prequal.prequal_reasons.gates_failed_explained.map((g: string, i: number) => (
              <p key={i} className="text-xs text-red-600 dark:text-red-400">{g}</p>
            ))}
          </div>
        )}
        {prequal.offer_fit_tags?.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-1">Offer fit</p>
            <div className="flex flex-wrap gap-1">{prequal.offer_fit_tags.map((t: string) => (
              <span key={t} className="px-1.5 py-0.5 text-xs bg-secondary text-secondary-foreground rounded">{t}</span>
            ))}</div>
          </div>
        )}
      </div>
    </div>
  );
}

function HypothesesTab({ fullResult, loading }: { fullResult: any; loading: boolean }) {
  if (loading) return <p className="text-sm text-muted-foreground">Loading hypotheses...</p>;
  const hypotheses = fullResult?.pain_hypotheses ?? [];
  if (hypotheses.length === 0) return <p className="text-sm text-muted-foreground">No pain hypotheses</p>;

  return (
    <div className="space-y-4">
      {hypotheses.map((h: any, idx: number) => (
        <div key={idx} className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-border bg-muted/30 flex items-center gap-2 flex-wrap">
            <span className={`px-2 py-0.5 text-xs font-medium rounded ${h.strength === 'high' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : h.strength === 'medium' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' : 'bg-secondary text-secondary-foreground'}`}>
              {h.strength}
            </span>
            <span className="px-2 py-0.5 text-xs bg-secondary text-secondary-foreground rounded">{h.pain_category}</span>
            <span className="text-xs text-muted-foreground">conf: {h.confidence?.toFixed(2)}</span>
            {h.do_not_outreach && <span className="px-2 py-0.5 text-xs bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 rounded">do not outreach</span>}
            {h.corroborated && <span className="px-2 py-0.5 text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 rounded">corroborated</span>}
          </div>
          <div className="p-4 space-y-3">
            <p className="text-sm leading-relaxed">{h.hypothesis}</p>
            {h.why_now && (
              <div className="p-3 bg-blue-50 dark:bg-blue-900/10 border border-blue-200 dark:border-blue-800 rounded-md">
                <p className="text-xs font-medium text-blue-800 dark:text-blue-300 mb-1">Why now · {h.why_now_urgency}</p>
                <p className="text-xs text-blue-700 dark:text-blue-400">{h.why_now}</p>
              </div>
            )}
            {h.suggested_offer_fit && (
              <div><p className="text-xs font-medium text-muted-foreground mb-1">Suggested offer fit</p><p className="text-xs">{h.suggested_offer_fit}</p></div>
            )}
            {h.recommended_personas?.length > 0 && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Target personas</p>
                <div className="flex flex-wrap gap-1">{h.recommended_personas.map((p: string) => (
                  <span key={p} className="px-1.5 py-0.5 text-xs bg-secondary text-secondary-foreground rounded">{p}</span>
                ))}</div>
              </div>
            )}
            {h.evidence?.length > 0 && (
              <CollapsibleSection title={`Evidence (${h.evidence.length})`}>
                <div className="space-y-2 mt-2">{h.evidence.map((ev: any, i: number) => (
                  <div key={i} className="p-2 bg-muted/30 rounded text-xs space-y-1">
                    <div className="flex gap-2 text-muted-foreground">
                      <span>Tier {ev.source_tier}</span>
                      {ev.date && <span>{ev.date}</span>}
                      <span className="font-mono truncate flex-1">{ev.url}</span>
                    </div>
                    {ev.verbatim_quote && <p className="italic text-muted-foreground line-clamp-3">{ev.verbatim_quote}</p>}
                  </div>
                ))}</div>
              </CollapsibleSection>
            )}
            {h.corroborated_by?.length > 0 && (
              <p className="text-xs"><span className="text-emerald-600">Corroborated by:</span> {h.corroborated_by.join(', ')}</p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function NewsTab({ fullResult, loading }: { fullResult: any; loading: boolean }) {
  if (loading) return <p className="text-sm text-muted-foreground">Loading news...</p>;
  const news = fullResult?.news_items ?? [];
  if (news.length === 0) return <p className="text-sm text-muted-foreground">No news items</p>;

  return (
    <div className="space-y-2">
      {news.map((n: any, idx: number) => (
        <div key={idx} className="bg-card border border-border rounded-lg p-3">
          <div className="flex items-start justify-between gap-4">
            <p className="text-sm font-medium flex-1">{n.title}</p>
            {n.confidence > 0.8 && <span className="text-xs px-1.5 py-0.5 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 rounded">{n.confidence.toFixed(1)}</span>}
          </div>
          {n.summary && <p className="text-xs text-muted-foreground mt-1">{n.summary}</p>}
          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
            {n.source_name && <span>{n.source_name}</span>}
            {n.source_type && <span className="px-1.5 py-0.5 bg-secondary rounded">{n.source_type}</span>}
            {n.date && <span>{n.date}</span>}
          </div>
          {n.tags?.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">{n.tags.map((t: string) => (
              <span key={t} className="px-1.5 py-0.5 text-xs bg-secondary text-secondary-foreground rounded">{t}</span>
            ))}</div>
          )}
          {n.url && <a href={n.url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline mt-1 block truncate">{n.url}</a>}
        </div>
      ))}
    </div>
  );
}

function RawTab({ fullResult, loading }: { fullResult: any; loading: boolean }) {
  if (loading) return <p className="text-sm text-muted-foreground">Loading...</p>;
  if (!fullResult) return <p className="text-sm text-muted-foreground">No full result data stored</p>;
  return <JsonViewer data={fullResult} />;
}
