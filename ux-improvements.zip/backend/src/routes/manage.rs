// src/routes/manage.rs
//
// Management endpoints:
//   POST /api/clients/:id/flush-companies  — delete all companies + reset cursors
//   POST /api/queue-status/retry           — requeue failed jobs

use axum::{
    extract::{Path, State},
    http::StatusCode,
    Json,
};
use serde::Deserialize;
use serde_json::{json, Value as JsonValue};
use tracing::{error, info};
use uuid::Uuid;

use crate::AppState;

// ============================================================================
// POST /api/clients/:id/flush-companies
// ============================================================================

#[derive(Debug, Deserialize)]
pub struct FlushCompaniesRequest {
    /// Also reset discovery cursors so next run starts fresh
    #[serde(default = "default_true")]
    pub reset_cursors: bool,
    /// Also cancel any pending/running jobs for this client
    #[serde(default = "default_true")]
    pub cancel_jobs: bool,
}

fn default_true() -> bool { true }

pub async fn flush_companies(
    State(state): State<AppState>,
    Path(client_id): Path<Uuid>,
    Json(body): Json<FlushCompaniesRequest>,
) -> Result<Json<JsonValue>, (StatusCode, Json<JsonValue>)> {
    // Verify client exists
    let exists: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM clients WHERE id = $1)")
        .bind(client_id)
        .fetch_one(&state.db)
        .await
        .map_err(|e| { error!("DB error: {:?}", e); db_error("DB error") })?;

    if !exists {
        return Err(not_found("Client not found"));
    }

    // 1. Delete all derived data (cascades handle most of it)
    //    Order matters — delete children before parents

    // Delete prequal results
    let prequal_deleted = sqlx::query(
        "DELETE FROM company_prequal WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)"
    ).bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);

    // Delete hypotheses
    let _ = sqlx::query(
        "DELETE FROM v3_hypotheses WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)"
    ).bind(client_id).execute(&state.db).await;

    // Delete evidence
    let _ = sqlx::query(
        "DELETE FROM v3_evidence WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)"
    ).bind(client_id).execute(&state.db).await;

    // Delete news
    let _ = sqlx::query(
        "DELETE FROM company_news WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)"
    ).bind(client_id).execute(&state.db).await;

    // Delete discovered URLs
    let _ = sqlx::query(
        "DELETE FROM discovered_urls WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)"
    ).bind(client_id).execute(&state.db).await;

    // Delete offer fit decisions
    let _ = sqlx::query(
        "DELETE FROM offer_fit_decisions WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)"
    ).bind(client_id).execute(&state.db).await;

    // Delete snapshots
    let _ = sqlx::query(
        "DELETE FROM company_snapshots WHERE company_id IN (SELECT id FROM companies WHERE client_id = $1)"
    ).bind(client_id).execute(&state.db).await;

    // Delete candidates
    let candidates_deleted = sqlx::query(
        "DELETE FROM company_candidates WHERE client_id = $1"
    ).bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);

    // Delete companies
    let companies_deleted = sqlx::query(
        "DELETE FROM companies WHERE client_id = $1"
    ).bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);

    // 2. Reset discovery cursors
    let mut cursors_reset: u64 = 0;
    if body.reset_cursors {
        // Reset fetch run cursors so next discovery starts from page 1
        cursors_reset = sqlx::query(
            "DELETE FROM company_fetch_runs WHERE client_id = $1"
        ).bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);
    }

    // 3. Cancel pending/running jobs
    let mut jobs_cancelled: u64 = 0;
    if body.cancel_jobs {
        jobs_cancelled = sqlx::query(
            r#"UPDATE jobs SET status = 'failed', last_error = 'cancelled (flush)', completed_at = NOW(), updated_at = NOW()
               WHERE client_id = $1 AND status IN ('pending', 'running')"#
        ).bind(client_id).execute(&state.db).await.map(|r| r.rows_affected()).unwrap_or(0);
    }

    info!(
        "Flushed client {}: {} companies, {} candidates, {} prequal results, {} cursors reset, {} jobs cancelled",
        client_id, companies_deleted, candidates_deleted, prequal_deleted, cursors_reset, jobs_cancelled
    );

    Ok(Json(json!({
        "data": {
            "companies_deleted": companies_deleted,
            "candidates_deleted": candidates_deleted,
            "prequal_deleted": prequal_deleted,
            "cursors_reset": cursors_reset,
            "jobs_cancelled": jobs_cancelled,
        }
    })))
}

// ============================================================================
// POST /api/queue-status/retry — requeue failed jobs
// ============================================================================

#[derive(Debug, Deserialize)]
pub struct RetryJobsRequest {
    /// Retry specific job IDs
    pub job_ids: Option<Vec<Uuid>>,
    /// Retry all failed jobs of this type
    pub job_type: Option<String>,
    /// Retry all failed jobs for this client
    pub client_id: Option<Uuid>,
    /// Only retry jobs failed after this time
    pub failed_after: Option<chrono::DateTime<chrono::Utc>>,
}

pub async fn retry_jobs(
    State(state): State<AppState>,
    Json(body): Json<RetryJobsRequest>,
) -> Result<Json<JsonValue>, (StatusCode, Json<JsonValue>)> {
    let retried = if let Some(ref ids) = body.job_ids {
        // Retry specific IDs
        let mut count: u64 = 0;
        for id in ids {
            let r = sqlx::query(
                r#"UPDATE jobs SET status = 'pending', last_error = NULL, attempts = attempts,
                   assigned_worker = NULL, completed_at = NULL, run_at = NOW(), updated_at = NOW()
                   WHERE id = $1 AND status = 'failed'"#,
            )
            .bind(id)
            .execute(&state.db)
            .await
            .map_err(|e| { error!("Retry error: {:?}", e); db_error("Retry failed") })?;
            count += r.rows_affected();
        }
        count
    } else {
        // Retry by type and/or client
        let r = sqlx::query(
            r#"UPDATE jobs SET status = 'pending', last_error = NULL,
               assigned_worker = NULL, completed_at = NULL, run_at = NOW(), updated_at = NOW()
               WHERE status = 'failed'
                 AND ($1::text IS NULL OR job_type = $1)
                 AND ($2::uuid IS NULL OR client_id = $2)
                 AND ($3::timestamptz IS NULL OR completed_at >= $3)"#,
        )
        .bind(body.job_type.as_deref())
        .bind(body.client_id)
        .bind(body.failed_after)
        .execute(&state.db)
        .await
        .map_err(|e| { error!("Retry error: {:?}", e); db_error("Retry failed") })?;
        r.rows_affected()
    };

    // Also reset any candidates that were stuck due to failed prequal jobs
    let candidates_reset = if body.job_type.as_deref() == Some("prequal_batch")
        || body.job_type.is_none()
    {
        sqlx::query(
            r#"UPDATE company_candidates SET status = 'new', prequal_started_at = NULL
               WHERE status = 'prequal_error'
                 AND ($1::uuid IS NULL OR client_id = $1)"#,
        )
        .bind(body.client_id)
        .execute(&state.db)
        .await
        .map(|r| r.rows_affected())
        .unwrap_or(0)
    } else {
        0
    };

    info!("Retried {} jobs, reset {} candidates", retried, candidates_reset);

    Ok(Json(json!({
        "data": {
            "jobs_retried": retried,
            "candidates_reset": candidates_reset,
        }
    })))
}

// ============================================================================
fn db_error(msg: &str) -> (StatusCode, Json<JsonValue>) {
    (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({ "error": { "code": "db_error", "message": msg } })))
}
fn not_found(msg: &str) -> (StatusCode, Json<JsonValue>) {
    (StatusCode::NOT_FOUND, Json(json!({ "error": { "code": "not_found", "message": msg } })))
}
