'use client';

import { useState } from 'react';
import { PageShell } from '@/components/layout/page-shell';
import { StatusBadge } from '@/components/ui/status-badge';
import { ScoreBar } from '@/components/ui/score-bar';
import { JsonViewer, CollapsibleSection } from '@/components/ui/json-viewer';
import { useCompanyDetail, useCompanyEvidence, useCompanyHypotheses, useCompanyNews, useRerunPrequal } from '@/lib/api/client';
import { formatDate, timeAgo } from '@/lib/utils/format';
import { RefreshCw } from 'lucide-react';

const TABS = ['overview', 'evidence', 'hypotheses', 'news', 'raw'] as const;
type Tab = typeof TABS[number];

export default function CompanyDetailPage({ params }: { params: { id: string } }) {
  const { id } = params;
  const { data, isLoading, isError, error } = useCompanyDetail(id);
  const [tab, setTab] = useState<Tab>('overview');
  const rerunPrequal = useRerunPrequal(id);

  // Lazy-loaded tabs
  const { data: evidenceData, isLoading: evidenceLoading } = useCompanyEvidence(id, tab === 'evidence');
  const { data: hypothesesData, isLoading: hypothesesLoading } = useCompanyHypotheses(id, tab === 'hypotheses');
  const { data: newsData, isLoading: newsLoading } = useCompanyNews(id, tab === 'news');

  if (isLoading) return <PageShell title="Loading..."><p className="text-muted-foreground">Loading company details...</p></PageShell>;
  if (isError) return <PageShell title="Error"><p className="text-red-600">Failed to load company: {(error as any)?.message ?? 'Unknown error'}</p><p className="text-xs text-muted-foreground mt-1">ID: {id}</p></PageShell>;
  if (!data?.data) return <PageShell title="Not found"><p className="text-muted-foreground">Company not found</p></PageShell>;

  const { company, latest_candidate, latest_prequal, run_history_count } = data.data;

  return (
    <PageShell
      title={company.name}
      description={company.domain ?? undefined}
      actions={
        <button
          onClick={() => rerunPrequal.mutate()}
          disabled={rerunPrequal.isPending}
          className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border hover:bg-muted disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${rerunPrequal.isPending ? 'animate-spin' : ''}`} /> Rerun prequal
        </button>
      }
    >
      {/* Company header info */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
        <div><span className="text-muted-foreground">Industry:</span> {company.industry ?? '—'}</div>
        <div><span className="text-muted-foreground">Employees:</span> {company.employee_count ?? '—'}</div>
        <div><span className="text-muted-foreground">Location:</span> {[company.city, company.region, company.country].filter(Boolean).join(', ') || '—'}</div>
        <div><span className="text-muted-foreground">Source:</span> {company.source ?? '—'}</div>
      </div>

      {/* Status + Score bar */}
      <div className="flex items-center gap-4 mb-6">
        {latest_candidate && <StatusBadge status={latest_candidate.status} />}
        {latest_prequal && <ScoreBar score={latest_prequal.score} />}
        <span className="text-xs text-muted-foreground">{run_history_count} run(s)</span>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border mb-4">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-3 py-2 text-sm font-medium border-b-2 transition-colors capitalize ${tab === t ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
            {t}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {tab === 'overview' && (
        <div className="space-y-4">
          {latest_prequal ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-card border border-border rounded-lg p-4 space-y-2">
                  <h3 className="text-sm font-medium">Prequal result</h3>
                  <div className="text-sm">Score: <span className="font-mono">{latest_prequal.score.toFixed(2)}</span></div>
                  <div className="text-sm">Qualifies: {latest_prequal.qualifies ? 'Yes' : 'No'}</div>
                  <div className="text-sm">Evidence: {latest_prequal.evidence_count ?? '—'} items from {latest_prequal.distinct_sources ?? '—'} sources</div>
                  {latest_prequal.gates_passed?.length ? (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {latest_prequal.gates_passed.map((g) => (
                        <span key={g} className="px-1.5 py-0.5 text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 rounded">{g}</span>
                      ))}
                    </div>
                  ) : null}
                  {latest_prequal.gates_failed?.length ? (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {latest_prequal.gates_failed.map((g) => (
                        <span key={g} className="px-1.5 py-0.5 text-xs bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 rounded">{g}</span>
                      ))}
                    </div>
                  ) : null}
                </div>
                <div className="bg-card border border-border rounded-lg p-4 space-y-2">
                  <h3 className="text-sm font-medium">Summary</h3>
                  <p className="text-sm text-muted-foreground">{latest_prequal.prequal_reasons?.summary ?? 'No summary available'}</p>
                  {latest_prequal.why_now_indicators?.length ? (
                    <div>
                      <p className="text-xs font-medium mt-2">Why now</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {latest_prequal.why_now_indicators.map((w) => (
                          <span key={w} className="px-1.5 py-0.5 text-xs bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 rounded">{w}</span>
                        ))}
                      </div>
                    </div>
                  ) : null}
                  {latest_prequal.offer_fit_tags?.length ? (
                    <div>
                      <p className="text-xs font-medium mt-2">Offer fit</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {(latest_prequal.offer_fit_tags as string[]).map((t) => (
                          <span key={t} className="px-1.5 py-0.5 text-xs bg-secondary text-secondary-foreground rounded">{t}</span>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>
            </>
          ) : (
            <p className="text-sm text-muted-foreground">No prequal results yet</p>
          )}
        </div>
      )}

      {tab === 'evidence' && (
        <div className="space-y-2">
          {evidenceLoading ? <p className="text-sm text-muted-foreground">Loading evidence...</p> : (
            (evidenceData?.data ?? []).length === 0 ? <p className="text-sm text-muted-foreground">No evidence</p> : (
              (evidenceData?.data ?? []).map((ev: any) => (
                <div key={ev.id} className="bg-card border border-border rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <StatusBadge status={ev.evidence_type ?? 'signal'} />
                    {ev.pain_category && <span className="text-xs font-mono text-muted-foreground">{ev.pain_category}</span>}
                    {ev.confidence != null && <span className="text-xs text-muted-foreground">conf: {ev.confidence.toFixed(2)}</span>}
                  </div>
                  <p className="text-sm">{ev.snippet}</p>
                  <p className="text-xs text-muted-foreground mt-1 truncate">{ev.url}</p>
                </div>
              ))
            )
          )}
        </div>
      )}

      {tab === 'hypotheses' && (
        <div className="space-y-2">
          {hypothesesLoading ? <p className="text-sm text-muted-foreground">Loading...</p> : (
            (hypothesesData?.data ?? []).length === 0 ? <p className="text-sm text-muted-foreground">No hypotheses</p> : (
              (hypothesesData?.data ?? []).map((h: any) => (
                <div key={h.id} className="bg-card border border-border rounded-lg p-3">
                  <p className="text-sm font-medium">{h.hypothesis}</p>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    {h.category && <span>{h.category}</span>}
                    {h.confidence != null && <span>conf: {h.confidence.toFixed(2)}</span>}
                    {h.evidence_count != null && <span>{h.evidence_count} evidence</span>}
                  </div>
                </div>
              ))
            )
          )}
        </div>
      )}

      {tab === 'news' && (
        <div className="space-y-2">
          {newsLoading ? <p className="text-sm text-muted-foreground">Loading...</p> : (
            (newsData?.data ?? []).length === 0 ? <p className="text-sm text-muted-foreground">No news</p> : (
              (newsData?.data ?? []).map((n: any) => (
                <div key={n.id} className="bg-card border border-border rounded-lg p-3">
                  <p className="text-sm font-medium">{n.title}</p>
                  {n.summary && <p className="text-xs text-muted-foreground mt-1">{n.summary}</p>}
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    {n.source_name && <span>{n.source_name}</span>}
                    {n.published_at && <span>{formatDate(n.published_at)}</span>}
                  </div>
                </div>
              ))
            )
          )}
        </div>
      )}

      {tab === 'raw' && (
        <JsonViewer data={data.data} />
      )}
    </PageShell>
  );
}
